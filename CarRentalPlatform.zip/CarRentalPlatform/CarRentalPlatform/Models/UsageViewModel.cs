﻿namespace CarRentalPlatform.Models
{
    public class UsageViewModel
    {
        public string clientId { get; set; } = string.Empty;
        public int callCount { get; set; }
    }
}
